const jsonFilePath = "/Data/Scrapbook.json";
var jsonInformation = [];

// two hard-code josn information

var date = new Date();
var offset = date.getTimezoneOffset();
console.log("time")
console.log(offset);

var screenshotInforFromDataBase = [];

console.log("this is the begining of this javascript file")


let fetchData = function(callback){
    console.log("this is fetch data in collection view.");
    $.get("./fetchrecordings", function(obj, status){
        screenshotInforFromDataBase = obj.data;
        console.log("this is information of screenshots from data base:");

        console.log(screenshotInforFromDataBase);

       
        if(screenshotInforFromDataBase.length != null){
            console.log("fetchData received:" + screenshotInforFromDataBase.length);
            console.log(screenshotInforFromDataBase);

            console.log(typeof screenshotInforFromDataBase);

            var len = screenshotInforFromDataBase.length;
            for(var index = 0; index < len; index++){
                console.log(screenshotInforFromDataBase[index].ScreenshotPictureName);
            }
        }
      else{
        console.log("there is no information recorded in the database, the lenght is 0.");
        console.log(screenshotInforFromDataBase);
        debugger;
      }

      callback();

    })
    .fail(function(response){
      console.error(response.responseText)
    });

}



// for each recording, extract information in an array
var pinterestLayout = (function ($) {
    // default setting
    var $board = null;
    var $columns = null;
    var pins = null;
    var colWidth = null;
    var colMargin = 20;
    var containerPadding = 10;

    var screenshotInformation = null;


    getWidth();

    function getDatePass(){
        let currentDate = new Date();
    }

    function getWidth(){
        var screenwidth = $(window).width();

        colWidth = (screenwidth - 220 ) / 4;
        console.log("width value is: ")
        console.log(colWidth);
    }

    // click search button

    var recordings = null;
    var searchedCollections = null;



    $('#searchButton').click(function(){

        

        var searchKeyString = document.getElementById("searchText").value;
        console.log("the seaching key word value is: ");
        console.log(searchKeyString);
    
        $.post("./searchKeyWord", {keyWord: searchKeyString}, function(obj, status){
            pins = obj.data;
            console.log("after searching keywords, the new pins is: ");
            console.log(pins);
            var searchCount = pins.length;
            var indicator = "<p> About " + searchCount.toString() +  " rearching results with keyword: " + searchKeyString + "</p>";
            $('#resultIndicate').html(indicator);
            // code here, problem
            drawBoard();
            // $(window).resize(drawBoard);
    
        });
        //     // set from newest to oldest
        //     pins = pins.reverse();
        //     $(window).resize(drawBoard).trigger('resize');
        // });
    });

    function testFunction(){
        console.log("this is test funcitn");
    }

    // refresh all recordings
    $('#resetButton').click(function(){
        // 
        pins = "";
        $("#resultIndicate").empty();
        init();
    });

  

    function init() {
        console.log("run init funtion.");
        $container = $('.container');
        $board = $('#board');
        // console.log(jsonFilePath)


        fetchData(function(){
            console.log("fetch data in callback");

            pins = screenshotInforFromDataBase;
            //$(window).resize(drawBoard).trigger('resize');
            drawBoard();
            // $(window).resize(drawBoard);
       
        });
        // register
        $(window).resize(drawBoard);
        

        $('#searchText').on("keyup", function(e) {
            if (e.keyCode == 13) {
                $('#searchButton').click();
                console.log('Enter');
            }
        });

    }


    function drawBoard() {
        // check whether the current collection is empty
        if (!pins.length) {
            alert("Sorry, but there is no recording!");
            return;
        }
        console.log("this is drawboard function");
        // get the width of current window
        var screenWidth = $(window).width();
        // set the number of columns, which is 4, default
        console.log("the window width is:");
        console.log(screenWidth);
        console.log("the colWidth is: ");
        console.log(colWidth);
        numColumns = Math.floor(screenWidth / (colWidth));
        console.log("the number of columns is:");
        console.log(numColumns);
        console.log("container width is:");
        var clientWidth = document.getElementById('container').clientWidth;
        console.log(clientWidth);
        var boardW = document.getElementById('board').clientWidth;
        console.log("board width is:");
        console.log(boardW);

        // numColumns = 4;
        // set the container's width
        // four columns with 5 margin paddings

        containerWidth = screenWidth - 40;
        // containerWidth = (numColumns * (colWidth + colMargin)) + containerPadding * 6;
        console.log("container set width: ");
        console.log(containerWidth);
        // set the container width for the "container"
        $container.css({ width: containerWidth });

        // Layout Columns
        $board.html('');
        for (i = 0; i < numColumns; i++) {
            // draw column layout
            $board.append('<div class="column" id="column' + i + ' "value="' + i + '"></div>');
        }

        $columns = $('.column');
        // set coulumn's width
        $columns.css({width: colWidth });
        var eachColumsWidth = $(".column").width();

        // Layout Pins
        var startindex = 0;
        var pinsLen = pins.length;

        addCol(0,pins)
                                
    }

    function addCol(recordingIndex, pins) {

        // the image is not loaded
        var pin = pins[recordingIndex];
        var pinWidth = $(".pin").width();
        console.log("single pin data: ");
        console.log(pin);

        console.log("id in database");
        console.log(pin._id);

        var idInDataBase = pin._id;

        record = pinTemplate(pin, recordingIndex, idInDataBase);


        column = shortestColumn()
        console.log("the shorest column is:");
        console.log(column);
        console.log(column.height());
        column.append(record);
        $("#image-pin_"+recordingIndex)[0].onload= function(){
            this.onload = null;
            recordingIndex++;
            if (recordingIndex<pins.length)
                addCol(recordingIndex,pins);
        }
    }

    // get the current shorest column index
    function shortestColumn() {
        $columns.sort(function (a, b) {
            if($(a).height() == $(b).height()){
                console.log("two heights are same");
                console.log($(a).attr('value'), $(b).attr('value'));
                return $(a).attr('value') - $(b).attr('value');
            }
            else return $(a).height() - $(b).height();
        });
        // if two columns are the same, return the first one
        console.log("sort result");
        console.log($columns);
        return $columns.first();
    }
    function displayImage() {
        
        console.log("Open a page to show further information.");
        // window.open(url,'Image','width=largeImage.stylewidth,height=largeImage.style.height,resizable=1');
    }


  /* 渲染模板 */
    function pinTemplate(singleRecording, recordingIndex, idInDataBase) {

        // console.log("Each pin information:")
        // console.log(options)

        console.log("this is pinTemplate function");

        var html = '';

        // extract informaiton from options seperatly

        var allApplicationInformationArray = singleRecording.ApplicationInformation;
        var capturedScreenshotInformationArray = singleRecording.CaptureRegion;

        console.log("each screenshot information");
        console.log(singleRecording);
        var screenshotPath = singleRecording.ImagePath;
        var screenshotDescription = singleRecording.ScreenshotText;
        var screenshotTitle = singleRecording.ScreenshotTitle;
        var screenshotTimeStamp = singleRecording.TimeStamp;
        var screenshotPictureName = singleRecording.ScreenshotPictureName;
        // 
        var screenshotName = singleRecording.ScreenshotPictureName;

        // print each information seperately
        // console.log(typeof(allApplicationInformationArray))
        // object
        // console.log(allApplicationInformationArray)
        // object
        // console.log(typeof(capturedScreenshotInformationArray))
        // console.log(capturedScreenshotInformationArray)
        // console.log(screenshotPath)
        // /Users/donghanhu/Documents/ScrapbookServer/Screenshot-09.30,13:20:52.jpg
        console.log(screenshotDescription)
        console.log(screenshotTitle)
        console.log(screenshotPictureName)
        console.log("this is screenshotTime stamp:");
        console.log(screenshotTimeStamp)
        var year = screenshotTimeStamp.substring(0, 4);
        var month = screenshotTimeStamp.substring(5, 7);
        var day = screenshotTimeStamp.substring(8, 10);
        var pastDateString = month + "/" + day + "/" + year;
        console.log(pastDateString);

        var pastDate = new Date(pastDateString);
        var curDate = new Date();
        var curYear = curDate.getFullYear().toString();
        console.log(curYear);
        var curMonth = curDate.getMonth() + 1;
        var curMonthString = curMonth.toString();
        console.log(curMonth);
        var curDay = curDate.getDate().toString();
        console.log(curDay);

        var curDateString = curMonthString + "/" + curDay + "/" + curYear;
        console.log(curDateString);

        var newCurDate = new Date(curDateString);
        var differentInTime = newCurDate.getTime() - pastDate.getTime();
        var differenceInDays = parseInt(differentInTime / (1000 * 3600 * 24));
        console.log(differenceInDays);

        var currentOtNot = true;
        if(differenceInDays > 0){
            currentOtNot = false;
        }
        var screenshotImageSource = "/Data/" + screenshotPictureName



        // set id for each screenshot in html page
        var pinId = "pin_" + recordingIndex;

        var pinSrc = screenshotPath;


        // code here to create href for each screenshot to click


        var temphref = "detailedView.html?" + "screenshotName=" + screenshotName + "&screenshotID=" + idInDataBase;



        html += `
        <a href=${temphref} class="pin" id="${pinId}" style="width:${colWidth-20}px" onclick="displayImage()">
            <h3>${screenshotTitle ? screenshotTitle : "Empty title here."} </h3>
        
            <img src="${screenshotImageSource}" id="image-${pinId}" >
            
            <small>${screenshotDescription? screenshotDescription : "Empty description here."}</small>
            <br>
            <small>${pastDateString ? pastDateString : "Empty time stamp here."}</small>
            <small>${currentOtNot == false ? differenceInDays + " days ago." : "Today's recording."} </small>
        </a>
        `
        
        return html;
        

    }
    

    init();

}(jQuery));






