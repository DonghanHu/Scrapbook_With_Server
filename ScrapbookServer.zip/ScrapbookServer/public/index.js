$(document).ready(function(){
    $("#exportData").click(function(){
        
        console.log("clicked export data button");
        var curDate = new Date();
        var dd = String(curDate.getDate()).padStart(2, '0');
        var mm = String(curDate.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = curDate.getFullYear();
        var hour = curDate.getHours(); // => 9
        var minute = curDate.getMinutes(); // =>  30
        var second = curDate.getSeconds();
        curDate = hour + '_' + minute + '_' + second + '_' + mm + '_' + dd + '_' + yyyy;
        console.log(curDate);
        $.post("./exportSavedData", {_date: curDate}, function(req, res){
            console.log(res);
        });
    });
});