var jsonFile = null;
var screenshotCollections;
var finalObj;
var logCollections;
var dateString;

$(document).ready(function(){
    $("#exportData").click(function(){
        
        console.log("clicked export data button");
        var curDate = new Date();
        var dd = String(curDate.getDate()).padStart(2, '0');
        var mm = String(curDate.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = curDate.getFullYear();
        var hour = curDate.getHours(); // => 9
        var minute = curDate.getMinutes(); // =>  30
        var second = curDate.getSeconds();
        curDate = hour + '_' + minute + '_' + second + '_' + mm + '_' + dd + '_' + yyyy;
        console.log(curDate);
        dateString = curDate;
        // $.post("./exportSavedData", {_date: curDate}, function(req, res){
        //     console.log(res);
        // });

        imageFunc(logFunc);
        // let finalData = {
        //     ...screenshotCollections,
        //     ...logCollections
        // };
        // console.log(finalData);
        
    });

    let imageFunc = function(callback){
        callback();
        $.get("./fetchrecordings", function(obj, status){
            let screenshotInforFromDataBase = obj.data;
            console.log(screenshotInforFromDataBase);
            console.log(typeof screenshotInforFromDataBase);
            screenshotCollections = screenshotInforFromDataBase;
            console.log(screenshotCollections);
            console.log(logCollections);
            console.log(typeof logCollections);
            let finalData = {...screenshotCollections, ...logCollections};
            console.log(finalData);

            Array.prototype.push.apply(screenshotCollections,logCollections);
            console.log(screenshotCollections);
            console.log(typeof screenshotCollections);
            
            let filename = dateString + "exportData.json";
            let contentType = "application/json;charset=utf-8;";
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                var blob = new Blob([decodeURIComponent(encodeURI(JSON.stringify(screenshotCollections)))], { type: contentType });
                navigator.msSaveOrOpenBlob(blob, filename);
            } else {
                var a = document.createElement('a');
                a.download = filename;
                a.href = 'data:' + contentType + ',' + encodeURIComponent(JSON.stringify(screenshotCollections));
                a.target = '_blank';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            }
    
        })
        .fail(function(response){
          console.error(response.responseText)
        });
        
        
    }

    let logFunc = function(){
        $.get("./fetchlogs", function(obj, status){

            let scrapbookLog = obj.data;
            console.log(scrapbookLog);
            // finalObj = screenshotCollections.concat(scrapbookLog);
            logCollections = scrapbookLog;

            

        //     let filename = "export2.json";
        //     let contentType = "application/json;charset=utf-8;";
        //     if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        //         var blob = new Blob([decodeURIComponent(encodeURI(JSON.stringify(finalData)))], { type: contentType });
        //         navigator.msSaveOrOpenBlob(blob, filename);
        //     } else {
        //         var a = document.createElement('a');
        //         a.download = filename;
        //         a.href = 'data:' + contentType + ',' + encodeURIComponent(JSON.stringify(finalData));
        //         a.target = '_blank';
        //         document.body.appendChild(a);
        //         a.click();
        //         document.body.removeChild(a);
        //     }
        }).fail(function(response){
          console.error(response.responseText)
        });
    }

    let makejsonFile = function (json) {
        var data = new Blob([json], {type: 'application/json'});

        // If we are replacing a previously generated file we need to
        // manually revoke the object URL to avoid memory leaks.
        if (jsonFile !== null) {
          window.URL.revokeObjectURL(jsonFile);
        }

        jsonFile = window.URL.createObjectURL(data);
        return jsonFile;
      };
});