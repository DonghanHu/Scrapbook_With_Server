// const { append } = require("express/lib/response");

// this is an array, and only the index 0 element is valid
var screenshotDetailInformation = [];

var revisedDetailInformation = [];

var pars = [];

var screenshotName = "";
var screenshotInformationId = "";

var scnshotPath;

var screenshotHeight;
var screenshotWidth;

var windowHeight;
var windowWidth;

var leftColumnW;
var leftColumnH;

var scnshotWidthResize;
var scnshotHeightResize;

var titleChanged = false;
var descriptionChanged = false;

var applicationNamesArray = [];
var applicationNameIndexArray = [];
var applicationInvisibleNameArray = [];

// true is unselected
var invisibleButtonInitialStatus = true;

let getWindowSize = function(){

    console.log("getWindow size function");
    console.log("the height of the current window is: ");
    console.log(window.innerHeight);
    console.log("the width of the current window is:");
    console.log(window.innerWidth);

    windowWidth = window.innerWidth;
    windowHeight = window.innerHeight;

    var leftColumnWidth = document.getElementById('leftCol');
    console.log("left column width is: ");
    console.log(leftColumnWidth.offsetWidth);

    var leftColumnWidth = document.getElementById('leftCol');
    console.log("left column width and height is: ");
    leftColumnW = leftColumnWidth.offsetWidth;
    leftColumnH = leftColumnWidth.offsetHeight;

    console.log(leftColumnW);
    console.log(leftColumnH);

}

function getScreenshotDimension(callback){
    const scnshot = new Image();
    scnshot.src = scnshotPath;
    var screenshotHeight1;
    var screenshotWidth1;
    scnshot.onload = function() {
            console.log("img dimentsion:");
            screenshotWidth1 = this.width;
            screenshotHeight1 = this.height;
            screenshotWidth = this.width;
            screenshotHeight = this.height;

            console.log(this.width + 'x' + this.height);
            console.log(screenshotHeight1, screenshotWidth1);
            updateImageSize();
    };
    // scrnshot.onload();
    // var func = function(){alert ("hello");}
    // func();
}

function updateImageSize(){

    console.log("in update Image size function: ");

    console.log("window height: ");
    console.log(windowHeight);


    var leftCol = document.getElementById('leftCol');
    var leftColWidth = leftCol.offsetWidth;
    console.log(leftColWidth);
    console.log(leftCol.offsetHeight);

    scnshotHeightResize = screenshotHeight;
    scnshotWidthResize = screenshotWidth;

    var paddingTop = 0;

    // W     nW
    //--  =  ---
    // h     nH

    var HWratio = (screenshotHeight * 1.0) / screenshotWidth;
    var WHratio = (screenshotWidth * 1.0) / screenshotHeight;

    if(screenshotHeight >= screenshotWidth){
        // set height as the max value
        console.log("H > w");
        scnshotHeightResize = windowHeight - 120;
    
        var scntempWidth = (screenshotWidth * 1.0 * scnshotHeightResize) / screenshotHeight;
        console.log(scntempWidth);
        console.log(leftColWidth);
        if(scntempWidth > leftColWidth){
                scnshotWidthResize = leftColWidth;
        }else{
            scnshotWidthResize = scntempWidth;
        }
        console.log("new image dimension size: Width & Height");
        console.log(scnshotWidthResize);
        console.log(scnshotHeightResize);

    } else{

        // code here, always at the top

        // leftCol: left frame, height is windowHeight - 120
        // scnshot height: scnshotHeightResize

        // width > height
        console.log("W > H");
        scnshotWidthResize = leftColumnW - 50;
        scnshotHeightResize = (screenshotHeight * 1.0 * scnshotWidthResize) / screenshotWidth;
        console.log("new image dimension size: Width & Height");
        console.log(scnshotWidthResize);
        console.log(scnshotHeightResize);

        var totalHeight = windowHeight - 120;
        paddingTop = (totalHeight - scnshotHeightResize) / 2;

    }
    $('#screenshot-temp').attr('width', scnshotWidthResize).attr('height', scnshotHeightResize);
    // console.log($('#leftCol').width);
    // console.log($('#leftCol').height);
    console.log("window height");
    console.log(windowHeight);
    console.log("leftcol width");
    console.log(leftColWidth);
    // didn't work for height setting
    $('#leftCol').height(windowHeight - 120);
    $('#leftCol').width(leftColWidth-50);


    $('#left-column').height(windowHeight - 120);
    $('#left-column').width(leftColWidth-50);


    $('#left-column').css('padding-top', paddingTop);

    // $('#leftCol').attr('height', windowHeight).attr('width', leftColWidth);
    console.log("after resize, the height of left col");
    console.log(document.getElementById('leftCol').offsetHeight);
    // $('#screenshot-temp').attr('width', scnshotWidthResize).attr('height', scnshotHeightResize);
}


// get parameters from url 
let getParsFromURL = function(){
    console.log("get parameter functions:");

    console.log(window.location.search);
    var urlSearchParams = new URLSearchParams(window.location.search);
    console.log(urlSearchParams);

    screenshotName = urlSearchParams.get('screenshotName');
    screenshotInformationId = urlSearchParams.get('screenshotID');

    if(screenshotName == null || screenshotInformationId == null){
        return console.log("parsed parameters are incorrect!");
    }
}


let fetchData = function(callback){
    // fetch screenshot data from database
    
    // code here
    $.post("./fetchRecordingInformation", {screenshotID: screenshotInformationId}, function(obj, status){

        screenshotDetailInformation = obj.data;
        console.log("this is fetched data from database through ID: ");
        console.log(screenshotDetailInformation);
        console.log(screenshotDetailInformation[0]);
        
        callback();

        if(screenshotDetailInformation.length != null){
            console.log("Detailed View: fetchData received: ");
            // console.log(screenshotDetailInformation);
        }
      else{
        console.log("Error: there is no information recorded in the database, the lenght is 0.");
        // console.log(screenshotInforFromDataBase);
        debugger;
      }

    }).fail(function(response){
            console.error(response.responseText);
    });

}

let screenshotHTML = function(){

    console.log("function: screenshotHTML code: ");
    console.log(screenshotDetailInformation);
    var screenshotNameTemp = screenshotDetailInformation[0].ScreenshotPictureName;
    console.log("screenshot name: ");
    console.log(screenshotNameTemp);

    var screenshotPathInFolder = "/Data/" + screenshotNameTemp;

    scnshotPath = screenshotPathInFolder;

    let screenshotHTMLCode = '\
            <img src = "' + screenshotPathInFolder + '" \
                    class="border border-dark" \
                    alt="caputed screenshot" \
                    id="screenshot-temp">\
            </img>\
            ';
    console.log(screenshotHTMLCode);
    return screenshotHTMLCode;
};

let generateList = function(applicationInfor, index){

    // var pageTitle = applicationInfor.SecondMetaData;
    // if(pageTitle == "Sorry, metadata for this software is not available!"){
    //     pageTitle = "Metadata is unavaliable!"
    // let singleListCode = '\
    //         <li>\
    //                 <div class="list-group-item"' + "id=button_" + index + '>\
    //                         <label>\
    //                                 <input type="checkbox" checked ' +  "id=check_" + index + " " + "value=" + index + '>\
    //                                         <span class="list-group-item-text">\
    //                                                 <a title = "' + generateAdditionalInformation(applicationInfor) + '">\
    //                                                 <i class="fa fa-fw">\
    //                                                 </i>\
    //                                                 <id=displayedInfor>' + applicationInfor.ApplicationName + " : " + pageTitle + '\
    //                                                 </id>\
    //                                         </span>\
    //                         </label>\
    //                 </div>\
    //         </li>\
    // ';
    // return singleListCode;
        let testString = "with spaces";
        var pageTitle = applicationInfor.SecondMetaData;
        if(pageTitle == "Sorry, metadata for this software is not available!" || pageTitle == "Currently, this information is empty!"){
                pageTitle = ""
        }
        else{
                pageTitle = " : " + pageTitle;
        }
        let visibleInfor = applicationInfor.VisibleOrNot
        console.log("visible inforamtion is: ");
        console.log(applicationInfor.VisibleOrNot);
        var appendString;
        // console.log(typeof visibleInfor);
        var flag = true;
        if(visibleInfor == "false" || visibleInfor == false){
            console.log("this is false");
            flag = false;
        }
        let singleListCode = '\
                <li' + (flag ? '' : ' class="invisibleWindow displayToggle"') + '>\
                        <div class="list-group-item"' + "id=button_" + index + '>\
                                <label>\
                                        <input type="checkbox" checked ' +  "id=check_" + index + " " + "value=" + index + '>\
                                                <span class="">\
                                                        <a title = "' + generateAdditionalInformation(applicationInfor) + '">\
                                                        <i class="fa fa-fw">\
                                                        </i>\
                                                        <span '+ (flag ? '' : ' class="invisibleWindowText"')+ '>' + applicationInfor.ApplicationName + pageTitle + '</span>\
                                                </span>\
                                </label>\
                        </div>\
                </li>\
        ';
        console.log(singleListCode);
        return singleListCode;
}

let uncheckedInvisableApps = function(){
    var liList = document.getElementById("applist").getElementsByTagName("li");
    
    for (var i = 0, len = liList.length; i < len; i++ ) {
            var curAppName = applicationNamesArray[i];
            // if is invisable and black
            if(applicationInvisibleNameArray.includes(curAppName)){
                    liList[i].children[0].children[0].children[0].checked = false;
                    // console.log(liList[i].children[0].children[0].children[1].children[0].children[1].textContent);
                    // darkgreen
                    // liList[i].children[0].children[0].children[1].children[0].children[1].style.color = 'green';
            }
    }
}

let generateAdditionalInformation = function(applicationInfor){
    // &#013;
    let additionalInformation =     "Application Name: " + applicationInfor.ApplicationName + " &#013;" + 
                                    "Application Category: " + applicationInfor.Category + " &#013;" + 
                                    "Application Information(1): " + applicationInfor.FirstMetaData + " &#013;" + 
                                    "Application Information(2): " + applicationInfor.SecondMetaData
    return additionalInformation;
}


$(window).resize(function() {
    console.log("window size changed.");
    // updateImageSize();
    location.reload();
});



$(document).ready(function(){


    getParsFromURL();
    console.log(screenshotName);
    console.log(screenshotInformationId);


    $(window).trigger('resize');
    // initital set
    getWindowSize();


    // fetch temp json information from the json file
    fetchData(function(){
        
        
            console.log("in document ready")

            // clear the 'left-column' first
            $('.left-column').empty();

            // screenshotDetailInformation
            
            // append new screenshot from the Data folder
            $('.left-column').append(screenshotHTML);


            // get screenshot dimentsion
            getScreenshotDimension();


            // document.getElementById('gadget_url').value = '';
            document.getElementById('RecordingTitle').value  = screenshotDetailInformation[0].ScreenshotTitle;

            document.getElementById('RecordingDescription').value = screenshotDetailInformation[0].ScreenshotText;

            //clear the list group 
            $("ul").empty();

            // console.log("screenshot information for applicaitons: ")
            // console.log(screenshotInformation.ApplicationInformation);

            var savedApplicationsInfor = screenshotDetailInformation[0].ApplicationInformation

            var appInforLength = savedApplicationsInfor.length;

            for(var i = 0; i < appInforLength; i++){

                $("#applist").append(generateList(savedApplicationsInfor[i], i));
            }
            // uncheckedInvisableApps();

            // open a detialed view
            let time = new Date().toISOString();
            // if this array is empty, then nothing will be saved into the database
            var emptyOpenedApps = [];
            $.post('/logFunc', {timeStamp: time, actionName: "OpenScreenshot", scnshotName: screenshotName, scnID: screenshotInformationId, openedApps: emptyOpenedApps}, function(obj, status){

            }).fail(function(response){
                console.error(response.responseText);
            });


    });

    $('#RecordingDescription').bind('input propertychange', function() {

        descriptionChanged = true;

        $('#saveButton').prop('disabled', false);
        // if(screenshotInformationId != null){
        //     // update information
        //     console.log("Description value:" + $('#RecordingDescription').val());
        //     var changedDescription = $('#RecordingDescription').val();
        //     // screenshotDetailInformation[0].ScreenshotText = changedDescription;
        //     // console.log(screenshotDetailInformation[0]);
        //     $.post("./updateRecordingDetailedView", {screenshotID: screenshotInformationId, changedData: {ScreenshotText: changedDescription}}, function(obj, status){

        //     }).fail(function(response){
        //             console.error(response.responseText);
        //     });
        // } else{
        //     alert("screeenshot information id is null");
        // }
        
        
    });

    $('#RecordingTitle').bind('input propertychange', function() {
        titleChanged = true;

        $('#saveButton').prop('disabled', false);
        // if(screenshotInformationId != null){
        //     // update information
        //     console.log($('#RecordingTitle').val());

        //     $.post("./updateRecordingDetailedView", {screenshotID: screenshotInformationId}, function(obj, status){

        //     }).fail(function(response){
        //             console.error(response.responseText);
        //     });
        // } else{
        //     alert("screeenshot information id is null");
        // }
    });

    $('#saveButton').prop('disabled', true);

    $("#saveButton").click(function(){

        // update operation
        let timeUpdate = new Date().toISOString();
        var emptyOpenedAppsUpdate = [];
        $.post('/logFunc', {timeStamp: timeUpdate, actionName: "UpdateScreenshot", scnshotName: screenshotName, scnID: screenshotInformationId, openedApps: emptyOpenedAppsUpdate}, function(obj, status){

        }).fail(function(response){
            console.error(response.responseText);
        });
        // 

        if(screenshotInformationId != null && (titleChanged == true || descriptionChanged == true)){
            // update information
            console.log("Description value:" + $('#RecordingDescription').val());
            var changedDescription = $('#RecordingDescription').val();
            var changedTitle = $('#RecordingTitle').val();

            $.post("./updateRecordingDetailedView", {screenshotID: screenshotInformationId, 
                changedData: {ScreenshotText: changedDescription, ScreenshotTit: changedTitle}}, 
                function(obj, status){

            
            }).fail(function(response){
                    console.error(response.responseText);
            });
            titleChanged = false;
            descriptionChanged = false;
            alert("Update has been saved!");
            $('#saveButton').prop('disabled', true);
        }else{
            alert("screeenshot information id is null, or nothing changed");
        }
        console.log(titleChanged);
    });

    // gray color or black
    $("#deleteButton").click(function(){

        // delete operation
        let timeDelete = new Date().toISOString();
        var emptyOpenedAppsDelete = [];
        $.post('/logFunc', {timeStamp: timeDelete, actionName: "DeleteScreenshot", scnshotName: screenshotName, scnID: screenshotInformationId, openedApps: emptyOpenedAppsDelete}, function(obj, status){

        }).fail(function(response){
            console.error(response.responseText);
        });

        console.log("delete button is clicked!")
        var response;
        if (!confirm("Are you sure you want to delete this screenshot?")) {
                return;
        } 
        
        // code here
        // step 1: delete the recording in the database
        $.post("./deleteRecordingDetailedView", {screenshotID: screenshotInformationId}, function(obj, status){

            
        }).fail(function(response){
                console.error(response.responseText);
        });
        // step 2: delete the screenshot
        $.post("./deleteScreenshotDetailedView", {screnenshotName: screnenshotName}, function(obj, status){

        }).fail(function(response){
                console.error(response.responseText);
        });
        
           

    });

    // alert window
    $("#openAllButton").click(function(){

        
        
        console.log("clicked the open all applicaitons button");
        var savedApplicationsInfor = screenshotDetailInformation[0].ApplicationInformation;
        var appLen = savedApplicationsInfor.length;
        console.log("this is application information in detialed view.")
        console.log(savedApplicationsInfor);

        var AllArrayName = [];
        var allIndexArray = [];

        for(var i = 0; i < appLen; i++){
            var appName = savedApplicationsInfor[i].ApplicationName;
            var appFirstInfor = savedApplicationsInfor[i].FirstMetaData;
            var appSecondInfor = savedApplicationsInfor[i].SecondMetaData;
            var appCate = savedApplicationsInfor[i].Category;
            AllArrayName.push(appName);
            allIndexArray.push(i);
            $.post('./openApplication', {_name: appName, _cate: appCate, _first: appFirstInfor, _second: appSecondInfor}, function(obj, status){

            }).fail(function(response){
                console.error(response.responseText);
            });
        }

        // open all apps operation
        let timeAll = new Date().toISOString();
        $.post('/logFunc', {timeStamp: timeAll, actionName: "OpenAllApps", scnshotName: screenshotName, scnID: screenshotInformationId, openedApps: AllArrayName, openIndex: allIndexArray}, function(obj, status){

        }).fail(function(response){
            console.error(response.responseText);
        });

    });

    // checkbox
    $("#flexCheckDefault").change(function() {

        $(".applistClass :checkbox").prop('checked', $(this).prop("checked"));
        console.log("clicked checkbox");

        // click selected all checkbox
        let timeCheckBox = new Date().toISOString();
        var emptyOpenedCheckBox = [];
        // go back button clicked
        $.post('/logFunc', {timeStamp: timeCheckBox, actionName: "CheckBoxClick", scnshotName: screenshotName, scnID: screenshotInformationId, openedApps: emptyOpenedCheckBox}, function(obj, status){

        }).fail(function(response){
            console.error(response.responseText);
        });
    });

    $("#InvisibleID").change(function() {
        $(".invisibleWindow").toggleClass("displayToggle")
    });

    // checkbox 2
    // $("#InvisibleID").change(function() {
    //     var liList = document.getElementById("applist").getElementsByTagName("li");
    //     // console.log(liList);
    //     // console.log(applicationNamesArray);
    //     // console.log(applicationNameIndexArray);
    //     // console.log(applicationInvisibleNameArray);
        
    //     for (var i = 0, len = liList.length; i < len; i++ ) {
    //             // var initialColor = liList[i].children[0].children[0].children[1].children[0].children[1].style.color;

    //             // console.log(liList[i]);
    //             var curAppName = applicationNamesArray[i];
    //             // if is invisable and black
    //             if(applicationInvisibleNameArray.includes(curAppName) && invisibleButtonInitialStatus){
    //                     // code here
    //                     // hightlight this li
    //                     liList[i].children[0].children[0].children[0].checked = true;
    //                     console.log(liList[i].children[0].children[0].children[1].children[0].children[1].textContent);
    //                     liList[i].children[0].children[0].children[1].children[0].children[1].style.color = 'darkgreen';
    //             }
    //             // if invisable and red
    //             else if (applicationInvisibleNameArray.includes(curAppName) && !invisibleButtonInitialStatus){
    //                     liList[i].children[0].children[0].children[1].children[0].children[1].style.color = 'black';
    //                     liList[i].children[0].children[0].children[0].checked = false;
    //             } else{
                        
    //             }
    //     }
    //     invisibleButtonInitialStatus = !invisibleButtonInitialStatus;
    // });


    $("#openSelectedButton").click(function(){
        console.log("clicked the open selected applicaitons button");

        var selectedRowArray = [];
        var selectedNameArray = [];
        var checkValues = $('input[type=checkbox]:checked').map(function() {
            // get row index
            let buttonIDValue = String($(this).attr("value"));
            console.log("value is: ");
            console.log(buttonIDValue);
            if(buttonIDValue != ""){
                selectedRowArray.push(buttonIDValue);
            }
            
            // console.log(selectedApps);
        }).get();

        console.log("this is save index array");
        console.log(selectedRowArray);

        var selectedIndex = selectedRowArray.length;
        for(var i = 0; i < selectedIndex; i++){
            var indexValue = selectedRowArray[i];
            var appInfor = screenshotDetailInformation[0].ApplicationInformation[indexValue];
            
            var appName = appInfor.ApplicationName;
            var appFirstInfor = appInfor.FirstMetaData;
            var appSecondInfor = appInfor.SecondMetaData;
            var appCate = appInfor.Category;
            selectedNameArray.push(appName);
            $.post('./openApplication', {_name: appName, _cate: appCate, _first: appFirstInfor, _second: appSecondInfor}, function(obj, status){

            }).fail(function(response){
                console.error(response.responseText);
            });
        }
        // open selected apps operation
        let timeSelected = new Date().toISOString();
        $.post('/logFunc', {timeStamp: timeSelected, actionName: "OpenSelectedApps", scnshotName: screenshotName, scnID: screenshotInformationId, openedApps: selectedNameArray, openIndex: selectedRowArray}, function(obj, status){

        }).fail(function(response){
            console.error(response.responseText);
        });

    });

    $("#goBackButton").click(function(){

        let timeGoback = new Date().toISOString();

        var emptyOpenedAppsGoback = [];
        // go back button clicked
        $.post('/logFunc', {timeStamp: timeGoback, actionName: "GoBack", scnshotName: screenshotName, scnID: screenshotInformationId, openedApps: emptyOpenedAppsGoback}, function(obj, status){

        }).fail(function(response){
            console.error(response.responseText);
        });

        var url = "collectionView.html";
        // detect change save or not
        if(titleChanged == true || descriptionChanged == true){
            if (confirm("You have made changes on this screenshot, but you didn't save it. Do you still want to leave?")) {
                titleChanged = false;
                descriptionChanged = false;
                window.location = url;

              } else {
                // do nothing
              }
        }else{
            window.location = url;
        }


        console.log("clicked the go back button");
        

    });


});
