// test json data
var screenshotJsonInformation = 
        {"TimeStamp":"2021.10.27,23:17:02",
        "WholeScreenshotOrNot":false,"ScreenshotText":"This is your memo...",
        "CaptureRegion":{"Right":990,"Height":462,"Bottom":756,"Left":286,"Top":294,"Width":704},
        "ScreenshotTitle":"Wednesday, Oct 27, 2021","ApplicationInformation":[{"Bottom":900,"Right":1440,"Top":0,"Rank":"first",
        "ApplicationName":"Google Chrome","Category":"Google Chrome","SecondMetaData":"(28 封私信 \/ 80 条消息) 首页 - 知乎","Left":0,"FirstMetaData":"https:\/\/www.zhihu.com\/"}],
        "ImagePath":"\/Users\/donghanhu\/Documents\/ScrapbookServer\/Public\/Data\/Screenshot-2021.10.27,23-17-02.jpg",
        "ScreenshotPictureName": "Screenshot-2021.10.27,23-17-02.jpg","Index":0}

const tempJsonFilePath = "/Data/tempScreenshotData.json";
var screenshotPathInFolder = "";

const fullJsonFile = 'Data/Scrapbook.json';

var screenshotHeight;
var screenshotWidth;

var windowHeight;
var windowWidth;

var leftColumnW;

var scnshotWidthResize;
var scnshotHeightResize;

var applicationNamesArray = [];
var applicationNameIndexArray = [];
var applicationInvisibleNameArray = [];

// true is unselected
var invisibleButtonInitialStatus = true;


// alternative recording data
var screenshotInformation = []

let getWindowSize = function(){
        console.log("getWindow size function");
        console.log("the height of the current window is: ");
        console.log(window.innerHeight);
        console.log("the width of the current window is:");
        console.log(window.innerWidth);

        windowWidth = window.innerWidth;
        windowHeight = window.innerHeight;

        var leftColumnWidth = document.getElementById('leftCol');
        console.log("left column width is: ");
        console.log(leftColumnWidth.offsetWidth);

        // offsetWidth, offsetHeight: The size of the visual box incuding all borders. Can be calculated by adding width/height and paddings and borders, if the element has display: block
        // clientWidth, clientHeight: The visual portion of the box content, not including borders or scroll bars , but includes padding . Can not be calculated directly from CSS, depends on the system's scroll bar size.
        leftColumnW = leftColumnWidth.clientWidth;
}


let fetchData = function(callback){

        console.log("in fetch data.");
        // fetch screenshot data
        // screenshotInformation = ...
        $.getJSON(tempJsonFilePath, function (json) {

                console.log("the count of json file is: ");
                console.log(json.length)

                console.log(json[0]);
                var count = json.length;
                if(count == 1){
                        screenshotInformation = json[0];
                }
                console.log("temp screenshot information in the temp json file is: ");
                console.log(screenshotInformation);
                // get screenshot name
                var screenshotName = screenshotInformation.ScreenshotPictureName;
                console.log("here is the screenshotPathInFolder");
                screenshotPathInFolder = "/Data/" + screenshotName;
                console.log(screenshotPathInFolder);
                callback();
        });

        

}

let titlePlaceholder = function(){

        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        let cur = new Date();
        let curYear = cur.getFullYear();
        //Months are zero based
        let curMonth = cur.getMonth() + 1;
        let curDate = cur.getDate();
        let curDay = days[cur.getDay()];
        let curHour = cur.getHours();

        // console.log(cur);

        var defaultPlaceholder = curDate + "-" + curMonth + "-" + curYear + " " + curDay
        return defaultPlaceholder

}

let generateAdditionalInformation = function(applicationInfor){
        var curAppName = applicationInfor.ApplicationName;
        console.log("print out application name!")
        console.log(curAppName);
        applicationNamesArray.push(curAppName);
        // applicationNamesArray.push(curAppName);
        // &#013;
        let additionalInformation =     "Application Name: " + applicationInfor.ApplicationName + " &#013;" + 
                                        "Application Category: " + applicationInfor.Category + " &#013;" + 
                                        "Application Information(1): " + applicationInfor.FirstMetaData + " &#013;" + 
                                        "Application Information(2): " + applicationInfor.SecondMetaData
                                        
        console.log(additionalInformation);
        return additionalInformation;
}

let generateList = function(applicationInfor, index){
        // <div class="list-group-item">&nbsp;<label><input type="checkbox"><span class="list-group-item-text"><i class="fa fa-fw"></i> App One</span></label></div>
        let testString = "with spaces";
        // add title after the name, code here
        // boarder for the screnshot
        var pageTitle = applicationInfor.SecondMetaData;
        // Sorry, metadata for this software is not available!
        if(pageTitle == "Sorry, metadata for this software is not available!" || pageTitle == "Currently, this information is empty!"){
                pageTitle = ""
        }
        else{
                pageTitle = " : " + pageTitle;
        }
        // if (pageTitle == "the result is empty"){
        //         pageTitle = "Null";
        // }
        console.log(applicationInfor.VisibleOrNot);
        let visibleInfor = applicationInfor.VisibleOrNot
        var flag = true;
        if(visibleInfor == "false" || visibleInfor == false){
            console.log("this is false");
            flag = false;
        }
        let singleListCode = '\
                <li' + (flag ? '' : ' class="invisibleWindow displayToggle"') + '>\
                        <div class="list-group-item"' + "id=button_" + index + '>\
                                <label>\
                                        <input type="checkbox" checked ' +  "id=check_" + index + " " + "value=" + index + '>\
                                                <span class="">\
                                                        <a title = "' + generateAdditionalInformation(applicationInfor) + '">\
                                                        <i class="fa fa-fw">\
                                                        </i>\
                                                        <span '+ (flag ? '' : ' class="invisibleWindowText"')+ '>' + applicationInfor.ApplicationName + pageTitle + '</span>\
                                                </span>\
                                </label>\
                        </div>\
                </li>\
        ';
        console.log(singleListCode);
        return singleListCode;
}

function getScreenshotDimension(callback){
        const scnshot = new Image();
        scnshot.src = screenshotPathInFolder;
        var screenshotHeight1;
        var screenshotWidth1;

        scnshot.onload = function() {
                console.log("get img dimentsion function:");
                screenshotWidth1 = this.width;
                screenshotHeight1 = this.height;
                screenshotWidth = this.width;
                screenshotHeight = this.height;

                console.log(this.width + 'x' + this.height);
                console.log(screenshotHeight1, screenshotWidth1);
                updateImageSize();
        };
        // scrnshot.onload();
        // var func = function(){alert ("hello");}
        // func();

        // callback();
        // here

        // callback(screenshotWidth1, screenshotHeight1);
}

function test(){
        console.log("nothgin");
}

function testFunc(w, h){
        console.log("test func");
        console.log(w + '&' + h);
}

function updateImageSize(){
        console.log("in update Image size function: ");
        console.log("window height: ");
        console.log(windowHeight);


        var leftCol = document.getElementById('leftCol');
        console.log("left column width: ");
        var leftColWidth = leftCol.offsetWidth;
        console.log(leftColWidth);
        console.log(leftCol.offsetHeight);

        var paddingTop = 0;

        //set initial screenshot size
        scnshotHeightResize = screenshotHeight;
        scnshotWidthResize = screenshotWidth;

        var HWratio = (screenshotHeight * 1.0) / screenshotWidth;
        var WHratio = (screenshotWidth * 1.0) / screenshotHeight;
    
        if(screenshotHeight >= screenshotWidth){
                console.log("H > w");
            // set height as the max value
            scnshotHeightResize = windowHeight - 120;
    
            var scntempWidth = (screenshotWidth * 1.0 * scnshotHeightResize) / screenshotHeight;
            if(scntempWidth > leftColWidth){
                    scnshotWidthResize = leftColWidth;
            }else{
                scnshotWidthResize = scntempWidth;
            }
            console.log("new image dimension size: Width & Height");
            console.log(scnshotWidthResize);
            console.log(scnshotHeightResize);
    
        } else{
            // width > height
                console.log("W > H");
                scnshotWidthResize = leftColumnW - 50;
                scnshotHeightResize = (screenshotHeight * 1.0 * scnshotWidthResize) / screenshotWidth;
                console.log("new image dimension size: Width & Height");
                console.log(scnshotWidthResize);
                console.log(scnshotHeightResize);

                var totalHeight = windowHeight - 120;
                paddingTop = (totalHeight - scnshotHeightResize) / 2;
        }
        $('#screenshot-temp').attr('width', scnshotWidthResize).attr('height', scnshotHeightResize);
        // set left column size
        $('#leftCol').height(windowHeight - 120);
        $('#leftCol').width(leftColWidth-50);
    
        $('#left-column').height(windowHeight - 120);
        $('#left-column').width(leftColWidth-50);

        $('#indicator').width(leftColWidth - 50);

        $('#left-column').css('padding-top', paddingTop);


        // $('#leftCol').attr('width', leftColWidth).attr('height', windowHeight);
        // console.log(document.getElementById('leftCol').offsetHeight);
}

let hightLightLiElement = function(){

};


// code here
let screenshotHTML = function(){
        // <img src = "' + "Data/Screenshot-2021.11.22,18-33-04.jpg" + '" \
        console.log("this is screenshotPathinFolder");
        console.log(screenshotPathInFolder);

        let screenshotHTMLCode = '\
                <img src = "' + screenshotPathInFolder + '" \
                        class="border border-dark" \
                        alt="caputed screenshot" \
                        id="screenshot-temp">\
                </img>\
                ';
        console.log(screenshotHTMLCode);


        return screenshotHTMLCode;
};

let uncheckedInvisableApps = function(){
        var liList = document.getElementById("applist").getElementsByTagName("li");
        
        for (var i = 0, len = liList.length; i < len; i++ ) {
                var curAppName = applicationNamesArray[i];
                // if is invisable and black
                if(applicationInvisibleNameArray.includes(curAppName)){
                        liList[i].children[0].children[0].children[0].checked = false;
                        // console.log(liList[i].children[0].children[0].children[1].children[0].children[1].textContent);
                        // darkgreen
                        // liList[i].children[0].children[0].children[1].children[0].children[1].style.color = 'green';
                }
        }
}

const ulTags = document.querySelector('ul');

$(window).resize(function() {
        console.log("window size changed.");
        // updateImageSize();
        location.reload();
});
// window.onresize = getScreenshotDimension();

$(document).ready(function(){

        $(window).trigger('resize');

        // initital set
        getWindowSize();

        // containter width is half of the window width


        // fetch temp json information from the json file
        fetchData(function(){

                // console.log("here is the screenshotPathInFolder");
                // screenshotPathInFolder = "/Data/" + screenshotName;
                console.log("fetch data id document ready");
                console.log(screenshotPathInFolder);

                // clear the 'left-column' first
                $('.left-column').empty();
                // append new screenshot from the Data folder
                $('.left-column').append(screenshotHTML);



                // get screenshot dimentsion
                getScreenshotDimension();


                let titlePlaceholderInfor = titlePlaceholder();

                // screenshot title placeholder
                $("#RecordingTitle").attr("placeholder", titlePlaceholderInfor);
                // screenshot description placeholder
                $("#RecordingDescription").attr("placeholder", "Please enter description for this recording");

                //clear the list group 
                $("ul").empty();

                // get invisibleNames
                applicationInvisibleNameArray = screenshotInformation.InvisiableApplicationNames;

                console.log("screenshot information for applicaitons: ")
                console.log(screenshotInformation.ApplicationInformation);
                var capturedApplicationsInfor = screenshotInformation.ApplicationInformation
                var appLen = capturedApplicationsInfor.length;
                console.log(appLen);
                for(var i = 0; i < appLen; i++){
                        console.log(capturedApplicationsInfor[i]);
                        console.log(capturedApplicationsInfor[i].ApplicationName);
                        // console.log(generateList(capturedApplicationsInfor[i]));
                        applicationNameIndexArray.push(i);
                        $("#applist").append(generateList(capturedApplicationsInfor[i], i));
                }

                // 
                // uncheckedInvisableApps();

        });

        // checkbox 1
        $("#flexCheckDefault").change(function() {

                $(".applistClass :checkbox").prop('checked', $(this).prop("checked"));
        });

        $("#InvisibleID").change(function() {
                $(".invisibleWindow").toggleClass("displayToggle")
        });

        // checkbox 2
/*        $("#InvisibleID").change(function() {
                var liList = document.getElementById("applist").getElementsByTagName("li");
                // console.log(liList);
                // console.log(applicationNamesArray);
                // console.log(applicationNameIndexArray);
                // console.log(applicationInvisibleNameArray);
                
                for (var i = 0, len = liList.length; i < len; i++ ) {
                        // var initialColor = liList[i].children[0].children[0].children[1].children[0].children[1].style.color;
 
                        
                        
                        // console.log(liList[i]);
                        var curAppName = applicationNamesArray[i];
                        // if is invisable and black
                        if(applicationInvisibleNameArray.includes(curAppName) && invisibleButtonInitialStatus){
                                // code here
                                // hightlight this li
                                // console.log(liList[i].children[0].children[0].children[0]);
                                liList[i].children[0].children[0].children[0].checked = true;
                                console.log(liList[i].children[0].children[0].children[1].children[0].children[1].textContent);
                                // darkgreen
                                liList[i].children[0].children[0].children[1].children[0].children[1].style.color = 'darkgreen';
                        }
                        // if invisable and red
                        else if (applicationInvisibleNameArray.includes(curAppName) && !invisibleButtonInitialStatus){
                                liList[i].children[0].children[0].children[1].children[0].children[1].style.color = 'black';
                                liList[i].children[0].children[0].children[0].checked = false;
                        } else{
                                
                        }
                }
                invisibleButtonInitialStatus = !invisibleButtonInitialStatus;

                // use index to find appname and
                // $(".applistClass :checkbox").prop('checked', $(this).prop("checked"));
        });
*/

        
        // gray color or black
        $("#deleteButton").click(function(){
                console.log("delete button is clicked!")
                var response;
                if (confirm("Are you sure you want to delete this recording?")) {
                        response = "Y";
                } else {
                        response = "N";
                }
                if(response == "Y"){

                        // call the delete temp screenshot function in server.js
                        console.log("this is the target image url to delete: ");
                        console.log(screenshotPathInFolder);
                        $.post("./deleteTempScreenshot", 
                                {_imageurl: screenshotPathInFolder},function(req, res){
                        });

                        console.log("confrim to delete");
                        // clear the json data
                        screenshotJsonInformation = [];
                        alert("This screenshot has been deleted successfully");
                        close();
                        window.top.close();
                        window.close();
                }
                else if (response == "N"){
                        console.log("cancel")
                }

        });
        
        // green color
        $("#saveButton").click(function(){
                console.log("save button is clicked!")
                alert("This screenshot has been save successfully!");
                
                // change the title and description
                screenshotInformation.ScreenshotTitle = $("#RecordingTitle").val();
                console.log("title information");
                console.log($("#RecordingTitle").val());

                if($('#RecordingTitle').val() == ''){
                        screenshotInformation.ScreenshotTitle = $('#RecordingTitle').attr('placeholder');
                    } else {
                        screenshotInformation.ScreenshotTitle = $('#RecordingTitle').val();
                }



                screenshotInformation.ScreenshotText = $("#RecordingDescription").val();
                console.log($("#RecordingDescription").val());

                console.log(screenshotInformation.ApplicationInformation);
                console.log("the length of original array is: ");
                console.log(screenshotInformation.ApplicationInformation.length);

                var rowArray = [];
                var checkValues = $('input[type=checkbox]:checked').map(function() {
                        //getElementById
                        console.log("id is: ");
                        let buttonIDString = String($(this).attr("id"));
                        console.log(buttonIDString);
                        let buttonIDValue = String($(this).attr("value"));
                        console.log("value is: ");
                        console.log(buttonIDValue);
                        rowArray.push(buttonIDValue);
                        // console.log(selectedApps);
                }).get();

                console.log("this is save index array");
                console.log(rowArray);

                var response;
                 
                var appLength = screenshotInformation.ApplicationInformation.length;
                console.log(appLength)

                var removeIndex = [];

                for(var i = 0; i < appLength; i++){
                        var indexString = String(i);
                        if(rowArray.includes(indexString)){
                                continue;
                        } else{
                                removeIndex.push(indexString);
                        }
                }
                console.log("this is remove array");
                console.log(removeIndex);

                for (var i = removeIndex.length -1; i >= 0; i--){
                        var indexInt = parseInt(removeIndex[i]);
                        screenshotInformation.ApplicationInformation.splice(indexInt, 1);
                }

                console.log(screenshotInformation.ApplicationInformation);
                console.log("new screenshot information");
                console.log(screenshotInformation);

                // save to database
                $.post("/saveTempScreenshot", screenshotInformation, function(req, res){

                }).fail(function(response){
                        console.error(response.responseText)
                });
                var url = "collectionView.html";
                window.location = url;


        });

});

// not used 
$('.list-group-item').on('click', function() {
        var $this = $(this);
        var $alias = $this.data('alias');
    
        $('.active').removeClass('active');
        $this.toggleClass('active')
    
        // Pass clicked link element to another function
        myfunction($this, $alias)
    })
    
    function myfunction($this, $alias) {
        console.log($this.text());  // Will log Paris | France | etc...
    
        console.log($alias);  // Will output whatever is in data-alias=""
    }



